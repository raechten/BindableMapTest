﻿using System;
using BindableMapTest.Controls;
using BindableMapTest.Models;
using Xamarin.Forms.Maps;
using Xamarin.Forms;
using BindableMapTest.ViewModels;

namespace BindableMapTest.Pages
{
	public class MapPage : ContentPage
	{
		public MapViewModel ViewModel
		{
			get { return BindingContext as MapViewModel; }
		}

		public MapPage()
		{
			BindingContext = new MapViewModel();
			var mapSpan = MapSpan.FromCenterAndRadius(Location.DefaultPosition(), Distance.FromKilometers(25));
			// This doesn't work
			var map = new BindableMap<Monkey>(mapSpan);
			map.SetBinding(BindableMap<Monkey>.ItemsSourceProperty, "Monkeys");


			// This works (Manually add all Pins. Obviously this does not take changes to the collection into account)
			//var map = new Map(mapSpan);
			//map.Pins.Clear();

			//foreach (var monkey in ViewModel.Monkeys)
			//{
			//	var location = monkey.Location;
			//
			//	if (location == null)
			//		return;

			//	var position = new Position(location.Latitude, location.Longitude);
			//	var pin = new Pin {
			//		Type = PinType.Place,
			//		Position = position,
			//		Label = monkey.Name
			//	};
			//
			//	map.Pins.Add(pin);
			//}

			var stack = new StackLayout { Spacing = 0 };
			stack.Children.Add(map);
			Content = stack;
		}
	}
}

