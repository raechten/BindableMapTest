﻿using Xamarin.Forms.Maps;
using BindableMapTest.Interfaces;
using Xamarin.Forms;
using System.Linq;
using System.Collections.ObjectModel;

namespace BindableMapTest.Controls
{
	public class BindableMap<T> : Map where T : IMapModel
	{
		public BindableMap(MapSpan region) : base(region)
		{
		}

		private void SetPins()
		{
			Pins.Clear();
			foreach (Pin pin in ItemsSource.Select(AsPin))
				Pins.Add(pin);
		}

		private static Pin AsPin(T item)
		{
			var location = item.Location;

			return new Pin { Label = item.Name, Position = new Position(location.Latitude, location.Longitude) };
		}

		public static readonly BindableProperty ItemsSourceProperty = 
			BindableProperty.Create<BindableMap<T>, ObservableCollection<T>>(m => m.ItemsSource, new ObservableCollection<T>());

		//
		// Properties
		//
		public ObservableCollection<T> ItemsSource
		{
			get { return (ObservableCollection<T>)GetValue(BindableMap<T>.ItemsSourceProperty); }
			set { SetValue(BindableMap<T>.ItemsSourceProperty, value); SetPins(); }
		}
	}

}

